# README

This is a prototype for an ecommerce site, NKRawson Creations.